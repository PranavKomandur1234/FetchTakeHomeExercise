package com.fetch.receiptservice.util;

import com.fetch.receiptservice.model.Item;
import com.fetch.receiptservice.model.Receipt;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.regex.Pattern;

public class PointsCalculator {

    public static int calculatePoints(Receipt receipt) {
        int points = 0;
        
        points += receipt.getRetailer().replaceAll("[^a-zA-Z0-9]", "").length();
        
        if (receipt.getTotal().matches("^\\d+\\.00$")) {
            points += 50;
        }
        
        if (receipt.getTotal().matches("^\\d+\\.((25)|(50)|(75)|(00))$")) {
            points += 25;
        }
        
        points += (receipt.getItems().size() / 2) * 5;
        
        for (Item item : receipt.getItems()) {
            if (item.getShortDescription().trim().length() % 3 == 0) {
                points += Math.ceil(Double.parseDouble(item.getPrice()) * 0.2);
            }
        }
        
        LocalDate purchaseDate = LocalDate.parse(receipt.getPurchaseDate());
        if (purchaseDate.getDayOfMonth() % 2 != 0) {
            points += 6;
        }
        
        LocalTime purchaseTime = LocalTime.parse(receipt.getPurchaseTime());
        if (purchaseTime.isAfter(LocalTime.of(14, 0)) && purchaseTime.isBefore(LocalTime.of(16, 0))) {
            points += 10;
        }
        
        return points;
    }
}
