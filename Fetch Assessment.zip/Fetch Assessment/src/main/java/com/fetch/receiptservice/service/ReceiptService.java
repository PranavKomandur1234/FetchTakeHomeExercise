package com.fetch.receiptservice.service;

import com.fetch.receiptservice.model.Receipt;
import com.fetch.receiptservice.util.PointsCalculator;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class ReceiptService {

    private final Map<String, Integer> receiptPointsMap = new HashMap<>();

    public String processReceipt(Receipt receipt) {
        String id = UUID.randomUUID().toString();
        int points = PointsCalculator.calculatePoints(receipt);
        receiptPointsMap.put(id, points);
        return id;
    }

    public Integer getPoints(String id) {
        return receiptPointsMap.get(id);
    }
}
